#include "LPC17xx.h"
#include "type.h"
#include "can.h"
#include "LED.h"
#include <math.h>
#include "UART.h"
#include <stdio.h>

// Programme de test de deplacement d'une patte pour la rotation de l'heapode
// Valeur initiale des servo moteurs 150

CAN_MSG MsgBuf_TX1, MsgBuf_TX2; /* TX and RX Buffers for CAN message */
CAN_MSG MsgBuf_RX1, MsgBuf_RX2; /* TX and RX Buffers for CAN message */
volatile uint32_t CAN1RxDone = FALSE, CAN2RxDone = FALSE;

void CAN_Initialisation(void);
void Send_CAN(int ID, int DataA, int DataB);
void send_position(int ID, int positionA, int positionB, int positionC);
void marche_avant(void);
void rotation (void);
void stand_position(void);
void stand_position2(void);
void test_monte(void);

#define DELAY 5000000
#define test_ID 6
#define PI 3.1415926535897932384626433832795
#define PIsur3 1.0471975511965977461542144610932


// DataA : paquet le plus lourd. Initialisation du Baudarate � 125kBps
int servo[6][3];//npatte et n_servo
extern void marche_sinus(float vitesse, float amplitude, short direction, short rotation);

int main( void )
{
	int amplitude = 15;
	int etat=0;
	char frame[6];
	int i=0, k=0, n_patte,a=0;
	int dir=-90,rot=0;
	float vitesse=1.0;
	

	LED_Init ();
	CAN_Initialisation();
	Init_UART();
	

	 while (1)
	 {
    int k=0;
		 // Montee suivie d'une descente d'une patte
		 
		
		send_position(3,150,70,190);//lever la patte
		for(k=0;k<DELAY;k++);
		send_position(4,150,150,150); // 
		for(k=0;k<2*DELAY;k++);//70000
		send_position(3,190,150,150);
		for(k=0;k<DELAY;k++);
		send_position(4,150,70,190);
		for(k=0;k<2*DELAY;k++);
		send_position(3,150,150,150);
		for(k=0;k<DELAY;k++);
		send_position(4,190,150,150);
		for(k=0;k<2*DELAY;k++);
		
		
		
		 
		 
		
	 } 
 
 
}


//void test_monte(void) 
//{
//	int i=0, k=0;
//	int pos_motA=70;
//	int pos_motB=0;
//	int pos_motC=0;
//	int j=0, m=0;
//		char etat = 0;
//		 // Montee suivie d'une descente d'une patte
//		for(i=0;i<2;i++)
//		 {
//						switch(etat)	{			
//							case 0:
//								pos_motB =150;
//								for(pos_motC=210;pos_motC>=70;pos_motC-=10){
//									pos_motB -=10; 
//									for(k=0;k<70000;k++){
//										send_position(i,150,pos_motB,pos_motC);
//									}
//								}
//								if(pos_motC==70 && pos_motB == 70) etat= 1;
//							case 1: 
//								pos_motB =70;
//								for(pos_motC=70;pos_motC<=150;pos_motC+=10){
//									pos_motB +=10;
//									for(j=0;j<70000;j++){	
//										send_position(i,150,pos_motB,pos_motC);
//									}
//								}
//								if(pos_motC==150 && pos_motB == 150)	etat= 0;

//						}
//		 } 
//}




void stand_position()
{
	int n_patte ;

	  for(n_patte=1;n_patte<=6 ;n_patte++)
	{
		servo[n_patte-1][0]=150; 
		servo[n_patte-1][1]=150;
		servo[n_patte-1][2]=150;
		send_position(n_patte,servo[n_patte-1][0],servo[n_patte-1][1],servo[n_patte-1][2]);//150,150,150);
	}
}
		

void marche_avant(void)
{
	int i=0;
	
	send_position(2,150,70,210);
	send_position(4,150,70,210);            //l�ve les pattes A
	send_position(6,150,70,210);
	for(i=0;i<2*DELAY;i++){}
		
	send_position(1,150,150,150);
	send_position(3,150,150,150);            //place les pattes B
	send_position(5,150,150,150);
	for(i=0;i<3*DELAY;i++){}
		
	send_position(2,170,90,160);
	send_position(4,150,100,240);            //avance les pattes A
	send_position(6,130,90,160);
	for(i=0;i<2*DELAY;i++){}

	//send_position(2,165,150,130);
	send_position(4,150,160,200);            //pose (1) les pattes A
	send_position(6,135,150,130);
	for(i=0;i<2*DELAY;i++){}
		
	send_position(2,165,150,130);
	send_position(4,150,160,160);            //pose les pattes A
	send_position(6,135,150,130);
	for(i=0;i<2*DELAY;i++){} 
			
	send_position(1,150,70,210);
	send_position(3,150,70,210);            //l�ve les pattes B
	send_position(5,150,70,210);
	for(i=0;i<DELAY;i++){}
		
	send_position(2,150,150,150);
	send_position(4,150,150,150);            //place les pattes A
	send_position(6,150,150,150);
	for(i=0;i<DELAY;i++){}
	
	send_position(1,150,90,140);
	send_position(5,180,70,140);            //avance les pattes B
	send_position(3,120,70,140);
	for(i=0;i<DELAY;i++){}
		
	send_position(1,150,155,125);
	send_position(5, 180,155,145);            //pose les pattes B
	send_position(3,120,155,145);
	for(i=0;i<2*DELAY;i++){}
		
}
void CAN_Initialisation(void)
{
SystemClockUpdate();
CAN_Init( BITRATE125K18MHZ );
//CAN_SetACCF( ACCF_OFF );
}


void Send_CAN(int ID,int DataA, int DataB)
{

  /* Even though the filter RAM is set for all type of identifiers,
  the test module tests explicit standard identifier only */
  MsgBuf_TX1.Frame = 0x00080000; /* 11-bit, no RTR, DLC is 8 bytes */
  MsgBuf_TX1.MsgID = ID; /* Explicit Standard ID */
  MsgBuf_TX1.DataA = DataA;
  MsgBuf_TX1.DataB = DataB;
	
	
	//Transmit initial message on CAN 1 
	CAN1_SendMessage( &MsgBuf_TX1 );

}
void stand_position2(void)
{
	int long i;
	send_position(1,150,150,150);
	for(i=1;i<10000;i++);
	send_position(2,150,150,150);
	for(i=1;i<10000;i++);
	send_position(3,150,150,150);
	for(i=1;i<10000;i++);
	send_position(4,150,150,150);
	for(i=1;i<10000;i++);
	send_position(5,150,150,150);
	for(i=1;i<10000;i++);
	send_position(6,150,150,150);
}

void send_position(int ID, int positionA, int positionB, int positionC)
{
	int DataA_sp = 0x00, DataB_sp = 0x00;
	int ID_sp = ID+0x200;
	DataA_sp = DataA_sp | positionA;
	DataA_sp = DataA_sp<<4;

	DataB_sp = DataB_sp | positionB;
	DataB_sp = DataB_sp<<18;
	DataB_sp = DataB_sp | positionC;

	Send_CAN(ID_sp, DataA_sp, DataB_sp);

}

