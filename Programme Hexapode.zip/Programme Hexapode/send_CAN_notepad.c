#include "lpc17xx.h"
#include "type.h"
#include "can.h"

CAN_MSG MsgBuf_TX1, MsgBuf_TX2; /* TX and RX Buffers for CAN message */
CAN_MSG MsgBuf_RX1, MsgBuf_RX2; /* TX and RX Buffers for CAN message */
volatile uint32_t CAN1RxDone = FALSE, CAN2RxDone = FALSE;
void CAN_Initialisation(void);
void Send_CAN(int Tx_DataA, int Tx_DataB);





// DataA : paquet le plus lourd. Initialisation du Baudarate � 125kBps pour commencer, voir fonction

int main( void )
{
	int Tx_DataA=0x11111111, Tx_DataB=0x22222222, Rx_DataA, Rx_DataB;
	
	CAN_Initialisation();
	
	while(1)
	{
	
		Send_CAN(Tx_DataA, Tx_DataB);
		
		if(CAN2RxDone == TRUE)
		{
			Rx_DataA = MsgBuf_RX2.DataA;
			Rx_DataB = MsgBuf_RX2.DataB;
			
			MsgBuf_RX2.Frame = 0x0;
			MsgBuf_RX2.MsgID = 0x0;
			MsgBuf_RX2.DataA = 0x0;
			MsgBuf_RX2.DataB = 0x0;
			
			CAN2RxDone = FALSE;
		}
	}
	
	

return 0;
}










/******************************************************************************************
**                                                                                       **
*******************************************************************************************/









void CAN_Initialisation(void)
{
SystemClockUpdate();
CAN_Init( BITRATE125K18MHZ );
}


void Send_CAN(int Tx_DataA, int Tx_DataB)
{
	int CAN_pursue=0;
  

  /* Even though the filter RAM is set for all type of identifiers,
  the test module tests explicit standard identifier only */
  MsgBuf_TX1.Frame = 0x00080000; /* 11-bit, no RTR, DLC is 8 bytes */
  MsgBuf_TX1.MsgID = EXP_STD_ID; /* Explicit Standard ID */
  MsgBuf_TX1.DataA = Tx_DataA;
  MsgBuf_TX1.DataB = Tx_DataB;
	
	while(CAN_pursue == 0)
  {
	/* Transmit initial message on CAN 1 */
	while ( !(LPC_CAN1->GSR & (1 << 3)) );
	if ( CAN1_SendMessage( &MsgBuf_TX1 ) == FALSE )
	{
	  continue;
	}
	else
	{
		CAN_pursue = 1;
	}
}
}





