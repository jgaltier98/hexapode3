#include "lpc17xx.h"
#include "type.h"
#include "can.h"

CAN_MSG MsgBuf_TX1, MsgBuf_TX2; /* TX and RX Buffers for CAN message */
CAN_MSG MsgBuf_RX1, MsgBuf_RX2; /* TX and RX Buffers for CAN message */

volatile uint32_t CAN1RxDone = FALSE, CAN2RxDone = FALSE;

int main( void )
{
	int CAN_pursue=0;
  /* SystemClockUpdate() updates the SystemFrequency variable */
  SystemClockUpdate();

  /* Please note, the bit timing is based on the setting of the 
  PCLK, if different PCLK is used, please read can.h carefully 
  and set your CAN bit timing accordingly. */  
  //CAN_Init( BITRATE100K24MHZ );
  CAN_Init( BITRATE125K18MHZ );	

  /* send one message from CAN1(TX) and verify received message on 
  CAN2(RX) if it's a match, both CAN TX and RX are working. 
  For more details on acceptance filter program, see Philips
  appnote AN10438 and the zip file associated with this appnote. */


  /* Test Acceptance Filter */
  /* Even though the filter RAM is set for all type of identifiers,
  the test module tests explicit standard identifier only */
  MsgBuf_TX1.Frame = 0x00080000; /* 11-bit, no RTR, DLC is 8 bytes */
  MsgBuf_TX1.MsgID = EXP_STD_ID; /* Explicit Standard ID */
  MsgBuf_TX1.DataA = 0x55CC55CC;
  MsgBuf_TX1.DataB = 0xCC55CC55;
	
	while(CAN_pursue == 0)
  {
	/* Transmit initial message on CAN 1 */
	while ( !(LPC_CAN1->GSR & (1 << 3)) );
	if ( CAN1_SendMessage( &MsgBuf_TX1 ) == FALSE )
	{
	  continue;
	}
	else
	{
		CAN_pursue = 1;
	}
}
}





