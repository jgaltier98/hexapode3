#include "lpc17xx.h"
#include "type.h"
#include "can.h"

CAN_MSG MsgBuf_TX1, MsgBuf_TX2; /* TX and RX Buffers for CAN message */
CAN_MSG MsgBuf_RX1, MsgBuf_RX2; /* TX and RX Buffers for CAN message */
volatile uint32_t CAN1RxDone = FALSE, CAN2RxDone = FALSE;

void CAN_Initialisation(void);
void Send_CAN(int ID, int DataA, int DataB);
void marche_avant(void);
//void marche_avant_2(void);
void stand_position(void);
void send_position(int ID, int positionA, int positionB, int positionC);
//void stand_position_2(void);
//void stand_position_3(void);
void danse(void);
void maintenance(void);

void initialise_GPIO(void);
void allume_led(int numero_led);

#define DELAY 1000000



// DataA : paquet le plus lourd. Initialisation du Baudarate � 125kBps

int main( void )
{
	int i=0;
	
	CAN_Initialisation();
	//danse ();
	//stand_position();

	for(i=0;i<30*DELAY;i++){}
	
	while(1)
	{
		maintenance();
		
		
		allume_led(1);
		
		for(i=0;i<DELAY;i++){}
		//marche_avant();
		
	
	}
return 0;
}






/******************************************************************************************
**                                                                                       **
*******************************************************************************************/
void stand_position(void)
{
	send_position(1,150,150,150);
	send_position(3,150,150,150);
	send_position(5,150,150,150);
	send_position(7,150,150,150);
	send_position(9,150,150,150);
	send_position(11,150,150,150);
}

void marche_avant(void)
{
	int i=0;
	
	send_position(3,150,70,210);
	send_position(7,150,70,250);            //l�ve les pattes A
	send_position(11,150,70,210);
	for(i=0;i<2*DELAY;i++){}
		
	send_position(1,150,150,150);
	send_position(5,150,150,150);            //place les pattes B
	send_position(9,150,150,150);
	for(i=0;i<3*DELAY;i++){}
		
	send_position(3,170,90,160);
	send_position(7,150,100,240);            //avance les pattes A
	send_position(11,130,90,160);
	for(i=0;i<2*DELAY;i++){}

	send_position(3,165,150,130);
	send_position(7,150,160,200);            //pose (1) les pattes A
	send_position(11,135,150,130);
	for(i=0;i<2*DELAY;i++){}
		
	send_position(3,165,150,130);
	send_position(7,150,160,160);            //pose les pattes A
	send_position(11,135,150,130);
	for(i=0;i<2*DELAY;i++){}
			
	send_position(1,150,70,210);
	send_position(5,150,70,210);            //l�ve les pattes B
	send_position(9,150,70,210);
	for(i=0;i<DELAY;i++){}
		
	send_position(3,150,150,150);
	send_position(7,150,150,150);            //place les pattes A
	send_position(11,150,150,150);
	for(i=0;i<DELAY;i++){}
	
	send_position(1,150,90,140);
	send_position(5,180,70,140);            //avance les pattes B
	send_position(9,120,70,140);
	for(i=0;i<DELAY;i++){}
		
	send_position(1,150,155,125);
	send_position(5,180,155,145);            //pose les pattes B
	send_position(9,120,155,145);
	for(i=0;i<2*DELAY;i++){}
		
}

void maintenance(void)
{
	
	send_position(1,150,60,230);
	send_position(3,150,60,230);
	send_position(5,150,60,230);
	send_position(7,150,60,230);
	send_position(9,150,60,230);
	send_position(11,150,60,230);
	
	
}



void danse (void)
{
	int i;
	
	send_position(1,150,200,180);
	send_position(5,150,200,180);
	send_position(9,150,200,180);
	send_position(3,150,200,180);
	send_position(7,150,200,180);
	send_position(11,150,200,180);
	for(i=0;i<DELAY;i++){}
		
	send_position(1,150,70,220);
	send_position(5,150,70,220);
	send_position(9,150,70,220);
	for(i=0;i<DELAY;i++){}
		
	send_position(1,150,70,200);
	send_position(5,150,70,200);
	send_position(9,150,70,200);
	for(i=0;i<DELAY;i++){}
		
	send_position(1,150,150,130);
	send_position(5,150,150,130);
	send_position(9,150,150,130);
	for(i=0;i<DELAY;i++){}
	
	send_position(3,150,70,220);
	send_position(7,150,70,220);
	send_position(11,150,70,220);
	for(i=0;i<DELAY;i++){}
		
	send_position(3,150,70,200);
	send_position(7,150,70,200);
	send_position(11,150,70,200);
	for(i=0;i<DELAY;i++){}
		
		
	
	send_position(1,150,150,130);
	send_position(3,150,150,130);
	send_position(5,150,150,130);
	send_position(7,150,150,130);
	send_position(9,150,150,130);
	send_position(11,150,150,130);
	for(i=0;i<DELAY;i++){}
	for(i=0;i<DELAY;i++){}
	
	
}


void CAN_Initialisation(void)
{
SystemClockUpdate();
CAN_Init( BITRATE125K18MHZ );
//CAN_SetACCF( ACCF_OFF );
}


void Send_CAN(int ID,int DataA, int DataB)
{

  /* Even though the filter RAM is set for all type of identifiers,
  the test module tests explicit standard identifier only */
  MsgBuf_TX1.Frame = 0x00080000; /* 11-bit, no RTR, DLC is 8 bytes */
  MsgBuf_TX1.MsgID = ID; /* Explicit Standard ID */
  MsgBuf_TX1.DataA = DataA;
  MsgBuf_TX1.DataB = DataB;
	
	
	//Transmit initial message on CAN 1 
	CAN1_SendMessage( &MsgBuf_TX1 );

}


void send_position(int ID, int positionA, int positionB, int positionC)
{
int DataA_sp = 0x00, DataB_sp = 0x00,i;
int ID_sp = ID;
DataA_sp = DataA_sp | positionA;
DataA_sp = DataA_sp<<4;

DataB_sp = DataB_sp | positionB;
DataB_sp = DataB_sp<<18;
DataB_sp = DataB_sp | positionC;
for(i=0;i<2000;i++)
{
Send_CAN(ID_sp, DataA_sp, DataB_sp);
Send_CAN(ID_sp, DataA_sp, DataB_sp);
Send_CAN(ID_sp, DataA_sp, DataB_sp);
Send_CAN(ID_sp, DataA_sp, DataB_sp);
Send_CAN(ID_sp, DataA_sp, DataB_sp);
Send_CAN(ID_sp, DataA_sp, DataB_sp);
Send_CAN(ID_sp, DataA_sp, DataB_sp);
Send_CAN(ID_sp, DataA_sp, DataB_sp);
Send_CAN(ID_sp, DataA_sp, DataB_sp);
}
}

void initialise_GPIO(void)
{
	LPC_GPIO1->FIODIR0 |= 0x13; // Initialisation L1,L2,L3
	LPC_GPIO1->FIODIR1 |= 0x05; // Initialisation L4,L5,L6
	LPC_GPIO1->FIODIR3 |= 0x38; // Initialisation L10,L11,12
}

void allume_led(int numero_led)
{
	if (numero_led == 1)
	{
		LPC_GPIO1->FIOPIN0 |= 0x01;
	}

	else if (numero_led == 2)
	{
		LPC_GPIO1->FIOPIN0 |= 0x02;
	}

	else if (numero_led == 3)
	{
		LPC_GPIO1->FIOPIN0 |= 0x10;
	}

	else if (numero_led == 4)
	{
		LPC_GPIO1->FIOPIN1 |= 0x01;
	}

	else if (numero_led == 5)
	{
		LPC_GPIO1->FIOPIN1 |= 0x02;
	}

	else if (numero_led == 6)
	{
		LPC_GPIO1->FIOPIN1 |= 0x04;
	}

	else if (numero_led == 10)
	{
		LPC_GPIO1->FIOPIN3 |= 0x08;
	}

	else if (numero_led == 11)
	{
		LPC_GPIO1->FIOPIN3 |= 0x10;
	}

	else
	{
		LPC_GPIO1->FIOPIN3 |= 0x20;
	}
}

void eteindre_led(int numero_led)
{
	if (numero_led == 1)
	{
		LPC_GPIO1->FIOPIN0 &= ~0x01;
	}

	else if (numero_led == 2)
	{
		LPC_GPIO1->FIOPIN0 &= ~0x02;
	}

	else if (numero_led == 3)
	{
		LPC_GPIO1->FIOPIN0 &= ~0x10;
	}

	else if (numero_led == 4)
	{
		LPC_GPIO1->FIOPIN1 &= ~0x01;
	}

	else if (numero_led == 5)
	{
		LPC_GPIO1->FIOPIN1 &= ~0x02;
	}

	else if (numero_led == 6)
	{
		LPC_GPIO1->FIOPIN1 &= ~0x04;
	}

	else if (numero_led == 10)
	{
		LPC_GPIO1->FIOPIN3 &= ~0x08;
	}

	else if (numero_led == 11)
	{
		LPC_GPIO1->FIOPIN3 &= ~0x10;
	}

	else
	{
		LPC_GPIO1->FIOPIN3 &= ~0x20;
	}
}


