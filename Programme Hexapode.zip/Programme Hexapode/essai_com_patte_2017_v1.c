#include "LPC17xx.h"
#include "type.h"
#include "can.h"
#include <math.h>


CAN_MSG MsgBuf_TX1, MsgBuf_TX2; /* TX and RX Buffers for CAN message */
CAN_MSG MsgBuf_RX1, MsgBuf_RX2; /* TX and RX Buffers for CAN message */
volatile uint32_t CAN1RxDone = FALSE, CAN2RxDone = FALSE;

void CAN_Initialisation(void);
void Send_CAN(int ID, int DataA, int DataB);
void send_position(int ID, int positionA, int positionB, int positionC);
void marche_avant(void);
void stand_position(void);

#define DELAY 1000000
#define test_ID 6
#define PI 3.1415926535897932384626433832795
#define PIsur3 1.0471975511965977461542144610932


// DataA : paquet le plus lourd. Initialisation du Baudarate � 125kBps

int main( void )
{
	int i=0;
	int servo1,servo2,servo3;
	float Z2=-165.0,Y2=0,X2=165.0,xd,yd; //repos -150,205
	const float L1=95.0,l1=50.0,l2=65.0,l3=150.0;
//	int k=0;
	
	CAN_Initialisation();
	servo1 = 150+180/PI*(atan(Y2/(X2-L1)));
	xd=sqrt(pow(Y2,2)+pow((X2-L1),2))-l1;
	yd=Z2;
	servo2 = 130 - 180.0/PI*(-atan(-yd/xd)+acos((pow(l3,2)-pow(xd,2)-pow(yd,2)-pow(l2,2))/(-2*l2*sqrt(pow(xd,2)+pow(yd,2)))));
	servo3 = 170-90 + 180.0/PI*(PI-acos((-pow(l3,2)+pow(xd,2)+pow(yd,2)-pow(l2,2))/(-2*l2*l3)));
	send_position(2,servo1,servo2,servo3);//150,130,170);
//	stand_position();
	while(1);
		{
//			stand_position();
//		
//			for(i=0;i<10*DELAY;i++);
//			marche_avant();
//			for(i=0;i<10*DELAY;i++);	
			
			send_position(test_ID,150,50,200);
			for(i=0;i<20*DELAY;i++);
			send_position(test_ID,200,50,200);
			for(i=0;i<20*DELAY;i++);
			send_position(test_ID,200,150,150);
			for(i=0;i<20*DELAY;i++);
			send_position(test_ID,150,150,150);
			for(i=0;i<20*DELAY;i++);
		}	
			
			return 0;
		
}

void stand_position(void)
{
	int long i;
	send_position(1,150,150,150);
	for(i=1;i<DELAY;i++);
	send_position(3,150,150,150);
	for(i=1;i<DELAY;i++);
	send_position(5,150,150,150);
	for(i=1;i<DELAY;i++);
	send_position(2,150,150,150);
	for(i=1;i<DELAY;i++);
	send_position(4,150,150,150);
	for(i=1;i<DELAY;i++);
	send_position(6,150,150,150);
	for(i=1;i<DELAY;i++);
}

void marche_avant(void)
{
	int i=0;
	
	send_position(2,150,50,200);
	send_position(4,150,50,200);            //l�ve les pattes A
	send_position(6,150,50,200);
	for(i=0;i<2*DELAY;i++){}
		
	send_position(1,150,150,150);
	send_position(3,150,150,150);            //place les pattes B
	send_position(5,150,150,150);
	for(i=0;i<2*DELAY;i++){}
		
	send_position(2,170,90,160);
	send_position(4,150,100,240);            //avance les pattes A
	send_position(6,130,90,160);
	for(i=0;i<2*DELAY;i++){}

	send_position(2,165,150,130);
	send_position(4,150,160,200);            //pose (1) les pattes A
	send_position(6,135,150,130);
	for(i=0;i<2*DELAY;i++){}
		
	send_position(2,165,150,130);
	send_position(4,150,160,160);            //pose les pattes A
	send_position(6,135,150,130);
	for(i=0;i<2*DELAY;i++){}
			
	send_position(1,150,70,210);
	send_position(3,150,70,210);            //l�ve les pattes B
	send_position(5,150,70,210);
	for(i=0;i<2*DELAY;i++){}
		
	send_position(2,150,150,150);
	send_position(4,150,150,150);            //place les pattes A
	send_position(6,150,150,150);
	for(i=0;i<2*DELAY;i++){}
	
	send_position(1,150,90,140);
	send_position(3,180,70,140);            //avance les pattes B
	send_position(5,120,70,140);
	for(i=0;i<2*DELAY;i++){}
		
	send_position(1,150,155,125);
	send_position(3,180,155,145);            //pose les pattes B
	send_position(5,120,155,145);
	for(i=0;i<2*DELAY;i++){}
}





/******************************************************************************************
**                                                                                       **
*******************************************************************************************/



void CAN_Initialisation(void)
{
SystemClockUpdate();
CAN_Init( BITRATE125K18MHZ );
//CAN_SetACCF( ACCF_OFF );
}


void Send_CAN(int ID,int DataA, int DataB)
{

  /* Even though the filter RAM is set for all type of identifiers,
  the test module tests explicit standard identifier only */
  MsgBuf_TX1.Frame = 0x00080000; /* 11-bit, no RTR, DLC is 8 bytes */
  MsgBuf_TX1.MsgID = ID; /* Explicit Standard ID */
  MsgBuf_TX1.DataA = DataA;
  MsgBuf_TX1.DataB = DataB;
	
	
	//Transmit initial message on CAN 1 
	CAN1_SendMessage( &MsgBuf_TX1 );

}


void send_position(int ID, int positionA, int positionB, int positionC)
{
	int DataA_sp = 0x00, DataB_sp = 0x00,i;
	int ID_sp = ID+0x200;
	DataA_sp = DataA_sp | positionA;
	DataA_sp = DataA_sp<<4;

	DataB_sp = DataB_sp | positionB;
	DataB_sp = DataB_sp<<18;
	DataB_sp = DataB_sp | positionC;

	Send_CAN(ID_sp, DataA_sp, DataB_sp);

}

