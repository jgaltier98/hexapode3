
#include "LPC17xx.h"

void Initialise_GPIO (void);
char Valeur_BP(void);
void Allumer_1LED(char Num_LED);
void Eteindre_1LED(char Num_LED);
void Ecriture_GPIO(unsigned char Valeur);
char Lecture_GPIO(void);
void AfficheLCD_code(short sortie);
char Valeur_Joystick_droit(void);
char Valeur_Joystick_gauche(void);
char Valeur_Joystick_haut(void);
char Valeur_Joystick_bas(void);
char Valeur_Joystick_centre(void);




