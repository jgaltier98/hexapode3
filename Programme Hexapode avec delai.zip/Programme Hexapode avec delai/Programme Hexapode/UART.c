// Bibliotheque UART

#include "LPC17xx.h"

// init UART 115200 bauds

void Init_UART()
{

//13.56	
LPC_PINCON->PINSEL4 = 0x000A000A; // Broche P2.8 pour TX2 et P2.9 pour RX2 et P2.1 / P2.0 pour TX1
LPC_SC->PCONP |= 0x01000010;
LPC_UART2->LCR |= 0x03;	// configuration

// R�glage de la vitesse de transmission
LPC_UART2->LCR |= 0x83; // For�age bit DLAB=1 (Demande autorisation de modification) //precedente 0x80
LPC_UART2->DLM = 0; // Pas de sur-division de PCLK //0
LPC_UART2->DLL = 0x9; // Division principale par 10 de PCLK //10
//LPC_UART2->FDR = 0xE5; // Division fractionnaire par 1,35 (DIVADDVAL=5 et MULVAL=14)
LPC_UART2->FDR = 0xC1;
//LPC_UART2->FDR = (14<<4)| 5;
LPC_UART2->LCR &= 0x7F; // For�age bit DLAB=0 (Fin d'autorisation de modification)



LPC_UART1->LCR |= 0x03;	// configuration


	//115200
// R�glage de la vitesse de transmission
LPC_UART1->LCR |= 0x83; // For�age bit DLAB=1 (Demande autorisation de modification)
LPC_UART1->DLM = 0; // Pas de sur-division de PCLK
LPC_UART1->DLL = 0x9; // Division principale par 10 de PCLK 
LPC_UART1->FDR = 0xC1; // Division fractionnaire par 1,35 (DIVADDVAL=5 et MULVAL=14)
LPC_UART1->LCR &= 0x7F; // For�age bit DLAB=0 (Fin d'autorisation de modification)

//38.4k
/*LPC_UART1->LCR |= 0x83; // For�age bit DLAB=1 (Demande autorisation de modification)
LPC_UART1->DLM = 0; // Pas de sur-division de PCLK
LPC_UART1->DLL = 0x19; // Division principale par 10 de PCLK 
LPC_UART1->FDR = 0xC2; // Division fractionnaire par 1,35 (DIVADDVAL=5 et MULVAL=14)
LPC_UART1->LCR &= 0x7F; // For�age bit DLAB=0 (Fin d'autorisation de modification)*/
//9600
/*LPC_UART1->LCR |= 0x83; // For�age bit DLAB=1 (Demande autorisation de modification)
LPC_UART1->DLM = 0; // Pas de sur-division de PCLK
LPC_UART1->DLL = 0x65; // Division principale par 10 de PCLK 
LPC_UART1->FDR = 0xC2; // Division fractionnaire par 1,35 (DIVADDVAL=5 et MULVAL=14)
LPC_UART1->LCR &= 0x7F; // For�age bit DLAB=0 (Fin d'autorisation de modification)*/

}


char UART_LIDAR_GetChar (void)
{
while ((LPC_UART2->LSR & 0x01)==0); // Attente caract�re re�u (attente tant que bit RDR=0)
																		// RDR : Receiver Data Ready (passe � 1 � chaque nouvelle r�ception)
return  LPC_UART2->RBR; 						// Lecture registre r�ception (remet automatiquement le bit RDR � 0)
}



void UART_LIDAR_PutChar (unsigned char caractere)
{
	//while ((LPC_UART2->LSR & 0x20)==0); // Attente buffer libre (attente tant que bit THRE=0)
	while (!(LPC_UART2->LSR & (1<<5)));																		//(passe � 1 quand un buffer emission vide)
	// Envoi de la donn�e (valeur 0x75)
	LPC_UART2->THR = caractere;
}

char UART_BT_GetChar (void)
{
//while ((LPC_UART1->LSR & 0x01)==0); // Attente caract�re re�u (attente tant que bit RDR=0)
if(	(LPC_UART1->LSR & 0x01)!=0){											// RDR : Receiver Data Ready (passe � 1 � chaque nouvelle r�ception)
	return  LPC_UART1->RBR; 						// Lecture registre r�ception (remet automatiquement le bit RDR � 0)
}
}



void UART_BT_PutChar (unsigned char caractere)
{
	while ((LPC_UART2->LSR & 0x20)==0); // Attente buffer libre (attente tant que bit THRE=0)
																			//(passe � 1 quand un buffer emission vide)
	// Envoi de la donn�e (valeur 0x75)
	LPC_UART1->THR = caractere;
}
