void Init_UART(void);

char UART_LIDAR_GetChar (void);

void UART_LIDAR_PutChar (unsigned char caractere);

char UART_BT_GetChar (void);

void UART_BT_PutChar (unsigned char caractere);
