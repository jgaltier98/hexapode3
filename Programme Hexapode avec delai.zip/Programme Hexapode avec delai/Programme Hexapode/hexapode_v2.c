#include <math.h>

//geometrie de l'hexapode

#define XDD1 100.0
#define YDD1 173.2
#define XDD2 200.0
#define YDD2 0.0
#define XDD3 100.0
#define YDD3 -173.2
#define XDD4 -100.0
#define YDD4 -173.2
#define XDD5 -200.0
#define YDD5 0.0
#define XDD6 -100.0
#define YDD6 173.2
#define ZDD -150.0


#define PI 3.1415926535897932384626433832795
#define PIsur3 1.0471975511965977461542144610932


void marche_sinus(float vitesse, float amplitude, short direction, short rotation);

extern int servo[6][3];

void marche_sinus(float vitesse, float amplitude, short direction, short rotation)
{
	unsigned char n_patte;
	float xdd[6],ydd[6],zdd[6];
	const float L1=95.0,l1=50.0,l2=65.0,l3=150.0;
	const float xddinit[6]={XDD1,XDD2,XDD3,XDD4,XDD5,XDD6};
	const float yddinit[6]={YDD1,YDD2,YDD3,YDD4,YDD5,YDD6};
	const float zddinit[6]={ZDD,ZDD,ZDD,ZDD,ZDD,ZDD};
	float cosp,cosi,sinp,sini,xd,yd,teta1,teta2,teta3,alpha;
	static float omega, t=0, Ampp=0,Ampi=0,dir,dirp,diri,Ampiz,Amppz;
	const float gamma1[6]={PI/3,0,-PI/3,-2*PI/3,-PI,2*PI/3};
	static char drapeaup=0, drapeaui=0,sens_rot=0, sens_rotp=0, sens_roti=0, avance;
	


	if (amplitude < 0)
		amplitude = - amplitude;
	
	if (amplitude > 30.0)
		amplitude = 30.0;

	if(rotation == 'h')
		sens_rot = -1;
	else if (rotation == 't')
		sens_rot = +1;
	else sens_rot = 0;

	if (vitesse < 0)
		vitesse = 0;

	if (vitesse > 10)
		vitesse = 10;
	
	
	dir = (float)direction*PI/180.0; //passage en radian de la direction
	if (dir < 0)
		avance = 0;
	else avance = 1;


	if (t==0)
	{
		Ampiz = amplitude;
		Amppz = amplitude;
	}

	if(vitesse == 0.0)  amplitude = 0;
	
	//modif de la valeur de omega que lorsque les pattes sont en haut
	if((omega != vitesse) && (vitesse != 0.0))
	{
		t = omega*t/vitesse;
		omega = vitesse;
	}

	//modif de Ampp ou dirp quand les pattes paires sont en haut
	if ((Ampp != amplitude) || (dirp != dir) || (sens_rotp != sens_rot))
	{	
		alpha = (-omega*t+PI)-2*PI*floorf((-omega*t+PI)/(2*PI));
		if ( (alpha < PI) && (alpha > (PI/2)))
			drapeaup=1;
		if ( (alpha < (PI/2)) && (drapeaup == 1))
		{
			Ampp = amplitude;
			Amppz= amplitude;
			dirp = dir;
			sens_rotp=sens_rot;
		}
	}
	
	//modif de Ampi quand les pattes impaires sont en haut
	if ((Ampi != amplitude)	|| (diri != dir) || (sens_roti != sens_rot))
	{	
		alpha = (-omega*t)-2*PI*floorf((-omega*t)/(2*PI));
		if ((alpha < PI) && (alpha > (PI/2)))
			drapeaui=1;
		if ((alpha < (PI/2))&&(drapeaui == 1))
		{
			Ampi = amplitude;
			Ampiz= amplitude;	
			diri = dir;
			sens_roti = sens_rot;
		}
	}

	if ((Ampp==amplitude) && (dirp==dir) && (sens_rotp==sens_rot))
			drapeaup = 0;

	if ((Ampi==amplitude) && (diri==dir) && (sens_roti==sens_rot))
			drapeaui = 0;


	t=t+0.02;
	cosp = cos(-omega*t+PI); //pour les pattes paires
  sinp = sin(-omega*t+PI);
	cosi = cos(-omega*t);  	//pour les pattes impaires
	sini = sin(-omega*t);
	
	//calcul des positions cart�siennes des pattes paires
	for(n_patte=1;n_patte<=6;n_patte=n_patte+2)
	{
		xdd[n_patte-1]=xddinit[n_patte-1]-Ampp*cosp*(sens_rotp*sin(gamma1[n_patte-1])+avance*sin(dirp));
		ydd[n_patte-1]=yddinit[n_patte-1]+Ampp*cosp*(sens_rotp*cos(gamma1[n_patte-1])+avance*cos(dirp));
		zdd[n_patte-1]=zddinit[n_patte-1]+Amppz*sinp;
	}
	
	for(n_patte=2;n_patte<=6;n_patte=n_patte+2)
	{
		xdd[n_patte-1]=xddinit[n_patte-1]-Ampi*cosi*(sens_roti*sin(gamma1[n_patte-1])+avance*sin(diri));
		ydd[n_patte-1]=yddinit[n_patte-1]+Ampi*cosi*(sens_roti*cos(gamma1[n_patte-1])+avance*cos(diri));
		zdd[n_patte-1]=zddinit[n_patte-1]+Ampiz*sini;
	}


	

	

	
	for(n_patte=1;n_patte<=3;n_patte++)
	{
		servo[n_patte-1][0]=(int)(150.0+180.0/PI*(atan((ydd[n_patte-1]-L1*sin(gamma1[n_patte-1]))/(xdd[n_patte-1]-L1*cos(gamma1[n_patte-1])))-gamma1[n_patte-1]));
		xd=sqrt(pow((ydd[n_patte-1]-L1*sin(gamma1[n_patte-1])),2)+pow((xdd[n_patte-1]-L1*cos(gamma1[n_patte-1])),2))-l1;
		yd=zdd[n_patte-1];
		teta2=180.0/PI*(-atan(-yd/xd)+acos((pow(l3,2)-pow(xd,2)-pow(yd,2)-pow(l2,2))/(-2*l2*sqrt(pow(xd,2)+pow(yd,2)))));
		servo[n_patte-1][1]=(int)(130.0-teta2);
		teta3=180.0/PI*(PI-acos((-pow(l3,2)+pow(xd,2)+pow(yd,2)-pow(l2,2))/(-2*l2*l3)));
		servo[n_patte-1][2]=(int)(170.0+teta3-90.0);
	}
	
	for(n_patte=4;n_patte<=6;n_patte++)
	{
		teta1=180.0/PI*(atan2((ydd[n_patte-1]-L1*sin(gamma1[n_patte-1])),(xdd[n_patte-1]-L1*cos(gamma1[n_patte-1])))-gamma1[n_patte-1]);
		if(teta1>180.0)
			teta1=teta1-360.0;
		servo[n_patte-1][0]=(int)(150.0+teta1);
		xd=sqrt(pow((ydd[n_patte-1]-L1*sin(gamma1[n_patte-1])),2)+pow((xdd[n_patte-1]-L1*cos(gamma1[n_patte-1])),2))-l1;
		yd=zdd[n_patte-1];
		teta2=180.0/PI*(-atan(-yd/xd)+acos((pow(l3,2)-pow(xd,2)-pow(yd,2)-pow(l2,2))/(-2*l2*sqrt(pow(xd,2)+pow(yd,2)))));
		servo[n_patte-1][1]=(int)(130.0-teta2);
		teta3=180.0/PI*(PI-acos((-pow(l3,2)+pow(xd,2)+pow(yd,2)-pow(l2,2))/(-2*l2*l3)));
		servo[n_patte-1][2]=(int)(170.0+teta3-90.0);
	}
}
