/*         DATA A   DATA B
	CAN : 0x00003FF0 0FFC03FF  */

void send_position(uint32 ID, uint32_t positionA, uint32_t positionB, uint32_t positionC);
void stand_position(void);
void marche_avant(void);


int main(void)
{
	stand_position();

	while(1)
	{
		marche_avant();
	}

	return 0;
}




void stand_position(void)
{
	send_position(1,180,140,210);
	send_position(2,180,140,210);
	send_position(3,180,140,210);
	send_position(4,180,140,210);
	send_position(5,180,140,210);
	send_position(6,180,140,210);
}



void marche_avant(void)
{
	send_position(2,180,120,200);
	send_position(4,180,120,200);            //lève les pattes paires
	send_position(6,180,120,200);
	for(i=0;i<1000;i++){}

	send_position(2,240,120,190);
	send_position(4,150,120,220);            //bouge les pattes paires en avant
	send_position(6,160,120,150);
	for(i=0;i<1000;i++){}

	send_position(1,160,140,150);
	send_position(3,150,150,220);            //bouge les pattes impaires en arrière
	send_position(5,240,140,190);
	for(i=0;i<1000;i++){}

	send_position(2,240,140,190);
	send_position(4,150,140,220);            //pose les pattes paires
	send_position(6,160,150,150);
	for(i=0;i<1000;i++){}

	send_position(1,160,120,150);
	send_position(3,150,120,220);            //lève les pattes impaires
	send_position(5,240,120,190);
	for(i=0;i<1000;i++){}

	send_position(1,180,120,200);
	send_position(3,180,120,200);            //aligne les pattes impaires
	send_position(5,180,120,200);
	for(i=0;i<1000;i++){}

	send_position(1,180,140,210);
	send_position(3,180,140,210);            //pose les pattes impaires
	send_position(5,180,140,210);
	for(i=0;i<1000;i++){}

	send_position(2,180,140,210);
	send_position(4,180,140,210);            //aligne les pattes paires
	send_position(6,180,140,210);
	for(i=0;i<1000;i++){}
}




void send_position(uint32_t ID, uint32_t positionA, uint32_t positionB, uint32_t positionC)
{
uint32_t DataA = 0x00, DataB = 0x00;
DataA = DataA | positionA;
DataA = DataA<<4;

DataB = DataB | positionB;
DataB = DataB<<18;
DataB = DataB | positionC;

send_CAN(ID, DataA, DataB);
}
